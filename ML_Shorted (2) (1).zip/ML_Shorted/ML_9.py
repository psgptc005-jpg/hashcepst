import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
# Load data
df = pd.read_csv("9_customer_purchases.csv")
# Vectorize product lists using TF-IDF
X = TfidfVectorizer().fit_transform(df["Products"])
# KMeans clustering
k = 3
model = KMeans(n_clusters=k, random_state=42)
df["Cluster"] = model.fit_predict(X)
# Label clusters manually
labels = {0: "Tech Enthusiast", 1: "Fashion & Beauty Lover", 2: "Home Appliance Shopper"}
df["Behavior Type"] = df["Cluster"].map(labels)
# Display results
print(df[["Customer", "Behavior Type"]].to_string(index=False))
