import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
# Load data from CSV
df = pd.read_csv("3_email_data.csv")
# Split data
X_train, X_test, y_train, y_test = train_test_split(
    CountVectorizer().fit_transform(df['text']), df['label'],
    test_size=0.3, random_state=42, stratify=df['label']
)
# Train model
m = LogisticRegression().fit(X_train, y_train)
print("Accuracy:", round(accuracy_score(y_test, m.predict(X_test)), 2))
# Predict new email
new_email = ["Congratulations! You've been selected for a cash prize."]
cv = CountVectorizer().fit(df['text'])
print("Prediction:", "Spam" if m.predict(cv.transform(new_email))[0] else "Not Spam")
