import pandas as pd, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.metrics import accuracy_score, mean_squared_error
# Load dataset
df = pd.read_csv("10_terrain_data.csv")
# Encode crop labels
le = LabelEncoder()
df["label_enc"] = le.fit_transform(df["label"])
# ---- Crop Classification ----
X, y = df.drop(["label","label_enc"], axis=1), df["label_enc"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
clf = RandomForestClassifier(random_state=42).fit(Xtr, ytr)
print("Crop Selection Accuracy:", round(accuracy_score(yte, clf.predict(Xte)), 2))
# ---- Yield Prediction ----
df["yield"] = df["rainfall"] * 20 + np.random.randint(1000, 5000, len(df))
Xy, yy = df.drop(["label","label_enc","yield"], axis=1), df["yield"]
Xt, Xv, yt, yv = train_test_split(Xy, yy, test_size=0.2, random_state=42)
reg = LinearRegression().fit(Xt, yt)
print("Yield MSE:", round(mean_squared_error(yv, reg.predict(Xv)), 2))
# ---- New Sample Test ----
sample = pd.DataFrame([[90,40,40,25.5,60.5,6.5,200]], columns=X.columns)
print("Recommended Crop:", le.inverse_transform(clf.predict(sample))[0])
print("Predicted Yield:", round(reg.predict(sample)[0], 2))
