from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

X, y = load_iris(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=42)
m = DecisionTreeClassifier().fit(Xtr, ytr)
print("Classes:", load_iris().target_names)
print("Accuracy:", round(accuracy_score(yte, m.predict(Xte)), 2))
print("Prediction:", load_iris().target_names[m.predict([[5.1, 3.5, 1.4, 0.2]])[0]])
print("Prediction:", load_iris().target_names[m.predict([[6.7, 3.1, 4.7, 1.5]])[0]])
