import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
# Load data from CSV
df = pd.read_csv("8_heart_data.csv")
# Split and scale
X, y = df.drop("target", axis=1), df["target"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
sc = StandardScaler(); Xtr, Xte = sc.fit_transform(Xtr), sc.transform(Xte)
# Train SVM and test
m = SVC(kernel='linear', class_weight='balanced').fit(Xtr, ytr)
yp = m.predict(Xte)
print("Accuracy:", round(accuracy_score(yte, yp), 2))
# Predict one sample
print("Heart Disease?", "Yes" if m.predict([Xte[0]])[0] else "No")
