import seaborn as sns
import matplotlib.pyplot as plt
# Load the tips dataset
tips = sns.load_dataset("tips")
print("Sample of the dataset:")
print(tips.head())
# Set theme
sns.set_theme(style="whitegrid")
# Create bar plot with updated errorbar argument
plt.figure(figsize=(8, 6))
sns.barplot(data=tips, x="day", y="tip")
plt.title("Average Tip by Day with Standard Deviation")
plt.xlabel("Day of the Week")
plt.ylabel("Average Tip")
plt.show()