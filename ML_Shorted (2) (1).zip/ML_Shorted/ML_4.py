import string, nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier

nltk.download('stopwords', quiet=True); nltk.download('wordnet', quiet=True)
stop, lem = set(stopwords.words('english')), WordNetLemmatizer()
clean = lambda t: ' '.join(lem.lemmatize(w) for w in t.lower().translate(str.maketrans('', '', string.punctuation)).split() if w not in stop)

data = [("I love this movie", "pos"), ("Hate this film", "neg"), ("Awesome day", "pos"), ("Worst ever", "neg")]
X, y = zip(*[(clean(t), l) for t, l in data])
v = TfidfVectorizer().fit(X); m = RandomForestClassifier().fit(v.transform(X), y)

print("Predictions:")
for t in ["Loved it", "Terrible film", "Amazing story", "Not good"]:
    print(f"{t} → {m.predict(v.transform([clean(t)]))[0]}")
