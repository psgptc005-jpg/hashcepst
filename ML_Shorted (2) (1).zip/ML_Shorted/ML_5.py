from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
# Step 1: Load the Iris dataset
iris = load_iris()
X = iris.data
y = iris.target
# Step 2: Split into training (70%) and testing (30%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
# Step 3: Create and train the KNN model (k = 3)
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, y_train)
# Step 4: Predict on test data
y_pred = model.predict(X_test)
# Step 5: Evaluate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy*100:.2f}%")
# Step 6: Test a new sample
new_sample = [[5.1, 3.5, 1.4, 0.2]]
prediction = model.predict(new_sample)
print("Predicted class for new sample:", load_iris().target_names[prediction[0]])
